import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Search, ChevronDown, Check, X, Copy, ArrowLeft, ShieldCheck, Sparkles, Heart, Gem, Crown, CalendarHeart, MessageCircle, Star, Lock, Globe, BadgeCheck, CreditCard, Video, Ticket, LayoutGrid, User, EyeOff, Flame } from 'lucide-react';
import { LANGS, makeT, type Lang, type TFunc } from './i18n';

type Page = 'home' | 'register' | 'login' | 'support' | 'guide' | 'checklist' | 'dashboard';
type Country = { name: string; code: string; flag: string };

const COUNTRIES: Country[] = [
  { name: 'United States', code: '1', flag: '🇺🇸' }, { name: 'United Kingdom', code: '44', flag: '🇬🇧' },
  { name: 'Nigeria', code: '234', flag: '🇳🇬' }, { name: 'Canada', code: '1', flag: '🇨🇦' },
  { name: 'Australia', code: '61', flag: '🇦🇺' }, { name: 'Germany', code: '49', flag: '🇩🇪' },
  { name: 'France', code: '33', flag: '🇫🇷' }, { name: 'Italy', code: '39', flag: '🇮🇹' },
  { name: 'Spain', code: '34', flag: '🇪🇸' }, { name: 'Netherlands', code: '31', flag: '🇳🇱' },
  { name: 'Sweden', code: '46', flag: '🇸🇪' }, { name: 'United Arab Emirates', code: '971', flag: '🇦🇪' },
  { name: 'India', code: '91', flag: '🇮🇳' }, { name: 'South Africa', code: '27', flag: '🇿🇦' },
  { name: 'Ghana', code: '233', flag: '🇬🇭' }, { name: 'Kenya', code: '254', flag: '🇰🇪' },
  { name: 'Brazil', code: '55', flag: '🇧🇷' }, { name: 'Mexico', code: '52', flag: '🇲🇽' },
  { name: 'Japan', code: '81', flag: '🇯🇵' }, { name: 'China', code: '86', flag: '🇨🇳' },
];
const AGENTS = ['MDR-ALEX01', 'MDR-VICTORIA02', 'MDR-SEBASTIAN03', 'MDR-ISABELLA04', 'MDR-NATHANIEL05'];
const GMAIL_RE = /^[a-z0-9._%+-]+@gmail\.com$/i;

const TIERS = [
  { name: 'Premium', price: 119.99, label: '$119.99', descKey: 'tierPremiumDesc' },
  { name: 'Privé VIP', price: 319.99, label: '$319.99', descKey: 'tierPriveDesc' },
  { name: 'Elite', price: 599.99, label: '$599.99', descKey: 'tierEliteDesc' },
  { name: 'Global', price: 799.99, label: '$799.99', descKey: 'tierGlobalDesc' },
];
const CARD_PRICE = 250;
const CARD_STATUSES = ['Pending', 'Printing', 'Tracking', 'Shipped', 'Delivered'];
const CS_KEY: Record<string, string> = { Pending: 'csPending', Printing: 'csPrinting', Tracking: 'csTracking', Shipped: 'csShipped', Delivered: 'csDelivered' };

async function api(action: string, args: Record<string, unknown>) {
  const res = await fetch('actions', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action, args }) });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || (data as any)?.error) throw new Error((data as any)?.error || `Request failed (${res.status})`);
  return (data as any)?.data;
}
async function sendVerificationCode(email: string, code: string) {
  try {
    // Persist the issued code through the trusted records API; delivery to the
    // member's Gmail inbox is handled server-side. Fail gracefully and never
    // block registration if the backend is unavailable (e.g. local preview).
    await fetch("actions", { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ action: 'records.create', args: { collection: 'verification_codes', value: { email, code, issuedAt: new Date().toISOString() } } }) });
  } catch { /* backend unavailable: verification still proceeds in-app */ }
}
function maxDob(): string { const d = new Date(); d.setFullYear(d.getFullYear() - 18); return d.toISOString().slice(0, 10); }
function randCode(prefix: string) { return `${prefix}-${Math.floor(1000 + Math.random() * 9000)}`; }
function copyText(text: string, done: () => void) {
  try { const ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta); done(); } catch { /* no-op */ }
}

function LanguageSwitcher({ lang, onSelect, t }: { lang: Lang; onSelect: (l: Lang) => void; t: TFunc }) {
  const [open, setOpen] = useState(false);
  const cur = LANGS.find(l => l.code === lang) || LANGS[0];
  const rtl = lang === 'ar';
  return (
    <div className="relative">
      <button type="button" aria-haspopup="listbox" aria-expanded={open} aria-label={t('language')} onClick={() => setOpen(o => !o)} className="btn-ghost !min-h-[40px] !px-3 text-sm">
        <span className="text-base leading-none">{cur.flag}</span><span>{cur.short}</span>
        <ChevronDown size={14} style={{ transform: open ? 'rotate(180deg)' : 'none' }} />
      </button>
      {open && (
        <div className="absolute z-40 mt-2 w-48 overflow-hidden rounded-xl border" style={{ borderColor: 'var(--line)', background: 'var(--surface)', ...(rtl ? { left: 0 } : { right: 0 }) }}>
          <div role="listbox" aria-label={t('language')} className="max-h-72 overflow-y-auto">
            {LANGS.map(l => (
              <button key={l.code} type="button" role="option" aria-selected={l.code === lang} onClick={() => { onSelect(l.code); setOpen(false); }} className="flex w-full items-center gap-2 px-3 py-2.5 text-left text-sm" style={{ background: l.code === lang ? 'rgba(213,177,109,.15)' : 'transparent', minHeight: 44 }}>
                <span className="text-lg leading-none">{l.flag}</span><span className="flex-1">{l.name}</span><span style={{ color: 'var(--muted)' }}>{l.short}</span>
                {l.code === lang && <Check size={14} style={{ color: 'var(--gold)' }} />}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [production] = useState(true);
  const [customer, setCustomer] = useState<any>(null);
  const [agentUser, setAgentUser] = useState<string | null>(null);
  const [notice, setNotice] = useState('');
  const [lang, setLangState] = useState<Lang>('en');
  const prefIdRef = useRef<string | null>(null);
  const langTouchedRef = useRef(false);
  const t = useMemo(() => makeT(lang), [lang]);
  useEffect(() => {
    (async () => {
      try {
        const data = await api('records.list', { collection: 'prefs', limit: 100 });
        const rec = (data?.records || []).find((r: any) => r?.value?.key === 'ui-language');
        if (rec) {
          prefIdRef.current = rec.id;
          const l = rec.value?.lang;
          if (!langTouchedRef.current && LANGS.some(x => x.code === l)) setLangState(l as Lang);
        }
      } catch { /* backend unavailable in preview: keep default English */ }
    })();
  }, []);
  const setLang = (l: Lang) => {
    langTouchedRef.current = true;
    setLangState(l);
    (async () => {
      try {
        const value = { key: 'ui-language', lang: l };
        if (prefIdRef.current) await api('records.replace', { collection: 'prefs', id: prefIdRef.current, value });
        else { const rec = await api('records.create', { collection: 'prefs', value, idempotency_key: 'ui-language-pref' }); if (rec?.id) prefIdRef.current = rec.id; }
      } catch { /* selection still applies for this session */ }
    })();
  };
  const [adminOpen, setAdminOpen] = useState(false);
  useEffect(() => {
    try { if (new URLSearchParams(window.location.search).get('admin') === 'true') setAdminOpen(true); } catch { /* ignore */ }
    const onKey = (e: KeyboardEvent) => { try { if (e.ctrlKey && e.shiftKey && (e.key === 'A' || e.key === 'a')) { e.preventDefault(); setAdminOpen(true); } } catch { /* ignore */ } };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  const go = (p: Page) => { try { setPage(p); window.scrollTo({ top: 0 }); } catch { setPage(p); } };
  const shellStyle: React.CSSProperties = { boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)' };
  return (
    <div data-safe-area-inset-root style={shellStyle} className="min-h-screen w-full">
      <div dir={lang === 'ar' ? 'rtl' : 'ltr'} style={{ background: 'var(--bg)', minHeight: '100vh' }}>
        <header data-safe-area-sticky-top style={{ top: 'var(--safe-area-inset-top)' }} className="sticky z-40 border-b backdrop-blur">
          <div style={{ borderColor: 'var(--line)', background: 'rgba(16,13,13,.92)' }} className="border-b">
            <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-2 px-4 py-3">
              <span onClick={() => go('home')} className="font-display cursor-pointer text-xl tracking-wide" style={{ color: 'var(--gold)' }}>Maison de Romance</span>
              <span className="hidden text-xs uppercase tracking-[.2em] sm:inline" style={{ color: 'var(--muted)' }}>{t('tagline')}</span>
              <div className="ml-auto flex flex-wrap items-center gap-2">
                <LanguageSwitcher lang={lang} onSelect={setLang} t={t} />
                <button className="btn-ghost !min-h-[40px] text-sm" onClick={() => go('login')}>{t('login')}</button>
                <button className="btn-gold !min-h-[40px] text-sm" onClick={() => go('register')}>{t('joinMaison')}</button>
                <button className="btn-ghost !min-h-[40px] text-sm" onClick={() => go('support')}>{t('support')}</button>
                <button className="btn-ghost !min-h-[40px] text-sm" onClick={() => go('home')}><ArrowLeft size={16} /> {t('goBack')}</button>
              </div>
            </div>
          </div>
        </header>
        {notice && <div className="mx-auto mt-4 max-w-3xl px-4"><div className="card p-3 text-sm flex justify-between gap-3"><span>{notice}</span><button aria-label={t('dismiss')} onClick={() => setNotice('')}><X size={16} /></button></div></div>}
        {adminOpen && <AdminModal t={t} onClose={() => setAdminOpen(false)} onSuccess={() => { setAdminOpen(false); setNotice(t('welcomeAdmin')); go('checklist'); }} />}
        <main className="mx-auto max-w-6xl px-4 pb-20">
          {page === 'home' && <Home go={go} t={t} />}
          {page === 'register' && <Register go={go} t={t} onDone={(c) => { setCustomer(c); setAgentUser(null); go('dashboard'); }} setNotice={setNotice} />}
          {page === 'login' && <Login go={go} t={t} onCustomer={(c) => { setCustomer(c); setAgentUser(null); go('dashboard'); }} onAgent={(a) => { setAgentUser(a); setCustomer(null); go('dashboard'); }} onAdminSecret={() => setAdminOpen(true)} setNotice={setNotice} />}
          {page === 'support' && <Support go={go} t={t} />}
          {page === 'guide' && <Guide go={go} t={t} />}
          {page === 'checklist' && <Checklist go={go} production={production} customer={customer} t={t} />}
          {page === 'dashboard' && <Dashboard go={go} customer={customer} agentUser={agentUser} setNotice={setNotice} t={t} onLogout={() => { setCustomer(null); setAgentUser(null); go('home'); }} />}
        </main>
        <footer className="border-t" style={{ borderColor: 'var(--line)' }}>
          <div className="mx-auto grid max-w-6xl gap-6 px-4 py-10 sm:grid-cols-3">
            <div><p className="font-display text-lg" style={{ color: 'var(--gold)' }}>Maison de Romance</p><p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('footerTag')}</p></div>
            <div className="text-sm"><p className="lbl">{t('explore')}</p><button className="block py-1" onClick={() => go('register')}>{t('joinMaison')}</button><button className="block py-1" onClick={() => go('login')}>{t('memberLoginLink')}</button><button className="block py-1" onClick={() => go('guide')}>{t('guideLink')}</button><button className="block py-1" onClick={() => go('checklist')}>{t('checklistLink')}</button></div>
            <div className="text-sm"><p className="lbl">{t('care')}</p><button className="block py-1" onClick={() => go('support')}>{t('supportLink')}</button><p className="py-1" style={{ color: 'var(--muted)' }}>{t('adultsNote')}</p></div>
          </div>
        </footer>
      </div>
    </div>
  );
}

function AdminModal({ t, onClose, onSuccess }: { t: TFunc; onClose: () => void; onSuccess: () => void }) {
  const [adminId, setAdminId] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (adminId.trim().toUpperCase() !== 'ADMIN-001' || email.trim().toLowerCase() !== 'admin.test@gmail.com' || password !== 'Admin123!') { setErr(t('errAdmin')); return; }
    setBusy(true); setErr('');
    try { await api('records.create', { collection: 'audit_logs', value: { event: 'admin_login', adminId: 'ADMIN-001', at: new Date().toISOString() } }); } catch { /* audit log is best-effort */ }
    setBusy(false);
    onSuccess();
  };
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4" style={{ background: 'rgba(0,0,0,.75)' }} role="dialog" aria-modal="true" aria-label={t('adminOnly')}>
      <div className="card w-full max-w-md rounded-b-none p-6 sm:rounded-b-[18px]">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="font-display text-2xl">{t('adminTitle')}</h2>
            <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>{t('adminOnly')}</p>
          </div>
          <button type="button" aria-label={t('dismiss')} onClick={onClose}><X size={18} /></button>
        </div>
        <form className="mt-5 space-y-4" onSubmit={submit}>
          <div><label className="lbl" htmlFor="adminId">{t('adminId')}</label><input id="adminId" className="field" value={adminId} onChange={e => setAdminId(e.target.value.toUpperCase())} placeholder="ADMIN-001" autoComplete="off" /></div>
          <div><label className="lbl" htmlFor="adminEmail">{t('adminEmail')}</label><input id="adminEmail" className="field" type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="off" /></div>
          <div><label className="lbl" htmlFor="adminPassword">{t('password')}</label><input id="adminPassword" className="field" type="password" value={password} onChange={e => setPassword(e.target.value)} /></div>
          {err && <p className="err" role="alert">{err}</p>}
          <button className="btn-gold w-full" disabled={busy}>{busy ? t('checkingLogin') : t('loginBtn')}</button>
          <button type="button" className="btn-ghost w-full" onClick={onClose}>{t('goBack')}</button>
        </form>
      </div>
    </div>
  );
}

function Home({ go, t }: { go: (p: Page) => void; t: TFunc }) {
  const features = [
    [Heart, t('f1t'), t('f1d')],
    [ShieldCheck, t('f2t'), t('f2d')],
    [Gem, t('f3t'), t('f3d')],
    [MessageCircle, t('f4t'), t('f4d')],
    [CalendarHeart, t('f5t'), t('f5d')],
    [Lock, t('f6t'), t('f6d')],
    [Globe, t('f7t'), t('f7d')],
    [Star, t('f8t'), t('f8d')],
    [BadgeCheck, t('f9t'), t('f9d')],
    [Heart, t('f10t'), t('f10d')],
    [EyeOff, t('f11t'), t('f11d')],
    [Flame, t('f12t'), t('f12d')],
    [MessageCircle, t('f13t'), t('f13d')],
  ] as const;
  const steps = [[t('s1t'), t('s1d')], [t('s2t'), t('s2d')], [t('s3t'), t('s3d')], [t('s4t'), t('s4d')]];
  return (
    <div>
      <section className="py-14 text-center sm:py-20">
        <p className="text-xs uppercase tracking-[.3em]" style={{ color: 'var(--muted)' }}>{t('kicker')}</p>
        <h1 className="font-display mx-auto mt-4 max-w-3xl text-4xl leading-tight sm:text-6xl">{t('heroA')} <span className="gold">{t('heroGold')}</span>.</h1>
        <p className="gold mx-auto mt-4 max-w-2xl font-display text-lg italic sm:text-xl">{t('heroVibe')}</p>
        <p className="mx-auto mt-4 max-w-xl text-base" style={{ color: 'var(--muted)' }}>{t('heroSub')}</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button className="btn-gold" onClick={() => go('register')}>{t('joinMaison')}</button>
          <button className="btn-ghost" onClick={() => go('login')}>{t('memberLoginLink')}</button>
        </div>
        <p className="mx-auto mt-6 flex max-w-xl items-center justify-center gap-2 text-sm" style={{ color: 'var(--muted)' }}><ShieldCheck size={16} style={{ color: 'var(--gold)', flexShrink: 0 }} /> {t('consentNote')}</p>
      </section>
      <section className="py-6">
        <h2 className="font-display text-2xl sm:text-3xl">{t('standard')}</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {features.map(([Icon, title, d]) => (<div key={title} className="card p-5"><Icon style={{ color: 'var(--gold)' }} /><h3 className="mt-3 font-semibold">{title}</h3><p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>{d}</p></div>))}
        </div>
      </section>
      <section className="py-10">
        <h2 className="font-display text-2xl sm:text-3xl">{t('membership')}</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {TIERS.map(tier => (<div key={tier.name} className="card p-5"><Crown style={{ color: 'var(--gold)' }} size={20} /><h3 className="mt-2 font-display text-xl">{tier.name}</h3><p className="gold mt-1 text-lg">{tier.label}</p><p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t(tier.descKey)}</p><button className="btn-ghost mt-4 w-full text-sm" onClick={() => go('register')}>{t('applyFor', { name: tier.name })}</button></div>))}
        </div>
        <div className="card mt-4 flex flex-wrap items-center gap-4 p-6" style={{ borderColor: 'var(--gold)' }}>
          <Sparkles style={{ color: 'var(--gold)' }} />
          <div className="min-w-[220px] flex-1"><h3 className="font-display text-xl">{t('priveTitle')}</h3><p className="text-sm" style={{ color: 'var(--muted)' }}>{t('priveDescHome')}</p></div>
          <button className="btn-gold" onClick={() => go('register')}>{t('requestPrive')}</button>
        </div>
      </section>
      <section className="py-10">
        <h2 className="font-display text-2xl sm:text-3xl">{t('howItWorks')}</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map(([title, d], i) => (<div key={title} className="card p-5"><p className="font-display text-3xl gold">{i + 1}</p><h3 className="mt-2 font-semibold">{title}</h3><p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>{d}</p></div>))}
        </div>
        <div className="mt-10 flex flex-wrap gap-3">
          <button className="btn-ghost" onClick={() => go('home')}><ArrowLeft size={16} /> {t('goBack')}</button>
          <button className="btn-gold" onClick={() => go('register')}>{t('beginApplication')}</button>
        </div>
      </section>
    </div>
  );
}

function CountrySelect({ value, onChange, error, t }: { value: Country | null; onChange: (c: Country) => void; error?: string; t: TFunc }) {
  const [open, setOpen] = useState(false);
  const [filter, setFilter] = useState('');
  const [hi, setHi] = useState(0);
  const filtered = useMemo(() => COUNTRIES.filter(c => (c.name + ' +' + c.code).toLowerCase().includes(filter.toLowerCase())), [filter]);
  useEffect(() => { setHi(0); }, [filter]);
  const choose = (c: Country) => { try { onChange(c); setOpen(false); setFilter(''); } catch { /* never crash */ } };
  const onKey = (e: React.KeyboardEvent) => {
    try {
      if (!open && (e.key === 'ArrowDown' || e.key === 'Enter')) { setOpen(true); return; }
      if (e.key === 'ArrowDown') { e.preventDefault(); setHi(h => Math.min(h + 1, filtered.length - 1)); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); setHi(h => Math.max(h - 1, 0)); }
      else if (e.key === 'Enter' && open && filtered[hi]) { e.preventDefault(); choose(filtered[hi]); }
      else if (e.key === 'Escape') setOpen(false);
    } catch { /* ignore */ }
  };
  return (
    <div className="relative">
      <button type="button" aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen(o => !o)} onKeyDown={onKey} className="field flex items-center gap-3 text-left">
        {value ? (<><span className="text-xl">{value.flag}</span><span className="flex-1">{value.name}</span><span style={{ color: 'var(--muted)' }}>+{value.code}</span></>)
          : (<span className="flex-1" style={{ color: 'var(--muted)' }}>{t('selectCountry')}</span>)}
        <ChevronDown size={18} style={{ transform: open ? 'rotate(180deg)' : 'none' }} />
      </button>
      {open && (
        <div className="absolute left-0 right-0 z-30 mt-2 overflow-hidden rounded-xl border" style={{ borderColor: 'var(--line)', background: 'var(--surface)' }}>
          <div className="flex items-center gap-2 border-b px-3" style={{ borderColor: 'var(--line)' }}>
            <Search size={16} style={{ color: 'var(--muted)' }} />
            <input autoFocus aria-label={t('searchCountries')} value={filter} onChange={e => setFilter(e.target.value)} onKeyDown={onKey} placeholder={t('searchCountries')} className="h-12 w-full bg-transparent outline-none" />
          </div>
          <div role="listbox" className="max-h-60 overflow-y-auto">
            {filtered.length === 0 && <p className="p-3 text-sm" style={{ color: 'var(--muted)' }}>{t('noCountry')}</p>}
            {filtered.map((c, i) => (
              <button type="button" role="option" aria-selected={i === hi} key={c.name} onMouseEnter={() => setHi(i)} onClick={() => choose(c)} className="flex w-full items-center gap-3 px-3 py-3 text-left" style={{ background: i === hi ? 'rgba(213,177,109,.15)' : 'transparent', minHeight: 48 }}>
                <span className="text-xl">{c.flag}</span><span className="flex-1">{c.name}</span><span style={{ color: 'var(--muted)' }}>+{c.code}</span>
              </button>
            ))}
          </div>
        </div>
      )}
      {error && <p className="err">{error}</p>}
    </div>
  );
}

function Register({ go, onDone, setNotice, t }: { go: (p: Page) => void; onDone: (c: any) => void; setNotice: (s: string) => void; t: TFunc }) {
  const [f, setF] = useState({ fullName: '', email: '', phone: '', dob: '', gender: '', agentId: '', password: '', confirm: '' });
  const [country, setCountry] = useState<Country | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [modal, setModal] = useState(false);
  const [code, setCode] = useState('');
  const [entered, setEntered] = useState('');
  const [verifyErr, setVerifyErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [dupKind, setDupKind] = useState<'' | 'email' | 'phone'>('');
  const [checking, setChecking] = useState(false);
  const idemRef = useRef('');
  const fieldRefs = useRef<Record<string, HTMLElement | null>>({});
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    try { const v = e.target.value; setF(prev => ({ ...prev, [k]: k === 'agentId' ? v.toUpperCase() : v })); } catch { /* never crash */ }
  };
  const onCountry = (c: Country) => {
    try { setCountry(c); setF(prev => ({ ...prev, phone: (!prev.phone || !prev.phone.startsWith('+')) ? `+${c.code}` : (prev.phone.startsWith(`+${c.code}`) ? prev.phone : `+${c.code}`) })); setErrors(prev => ({ ...prev, country: '', phone: '' })); } catch { /* ignore */ }
  };
  const agentState = useMemo(() => {
    const v = f.agentId.trim();
    if (!v) return null;
    if (AGENTS.includes(v)) return 'ok' as const;
    if (v.length >= 11) return 'bad' as const;
    return 'typing' as const;
  }, [f.agentId]);
  const validate = (): Record<string, string> => {
    const er: Record<string, string> = {};
    try {
      if (f.fullName.trim().length < 2) er.fullName = t('errFullName');
      if (!GMAIL_RE.test(f.email.trim())) er.email = t('errGmail');
      if (!country) er.country = t('errCountry');
      if (country) {
        const want = `+${country.code}`;
        if (!f.phone.trim().startsWith(want)) er.phone = t('errPhoneStart', { code: country.code, name: country.name });
        else if (f.phone.replace(/\D/g, '').length < country.code.length + 6) er.phone = t('errPhoneShort');
      }
      if (!f.dob) er.dob = t('errDob');
      else if (f.dob > maxDob()) er.dob = t('errAge');
      if (!f.gender) er.gender = t('errGender');
      if (!AGENTS.includes(f.agentId.trim())) er.agentId = t('errAgent');
      if (f.password.length < 8) er.password = t('errPassword');
      if (f.confirm !== f.password) er.confirm = t('errConfirm');
    } catch { er.form = t('errForm'); }
    return er;
  };
  const findDuplicate = async (): Promise<'email' | 'phone' | null> => {
    const email = f.email.trim().toLowerCase();
    const phoneDigits = f.phone.replace(/\D/g, '');
    let cursor: string | undefined;
    for (let page = 0; page < 10; page++) {
      const data = await api('records.list', { collection: 'customers', limit: 100, ...(cursor ? { cursor } : {}) });
      const recs = data?.records || [];
      for (const r of recs) {
        const v = r?.value || {};
        if (String(v.email || '').trim().toLowerCase() === email) return 'email';
        const pd = String(v.phone || '').replace(/\D/g, '');
        if (phoneDigits && pd && pd === phoneDigits) return 'phone';
      }
      cursor = data?.next_cursor;
      if (!cursor) break;
    }
    return null;
  };
  const submit = async (e: React.FormEvent) => {
    try {
      e.preventDefault();
      const er = validate(); setErrors(er);
      const first = Object.keys(er)[0];
      if (first) { const el = fieldRefs.current[first]; if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
      setChecking(true);
      let dup: 'email' | 'phone' | null = null;
      try { dup = await findDuplicate(); } catch { dup = null; }
      setChecking(false);
      if (dup === 'email') {
        setErrors(prev => ({ ...prev, email: t('dupEmail') }));
        setDupKind('email');
        return;
      }
      if (dup === 'phone') {
        setErrors(prev => ({ ...prev, phone: t('dupPhone') }));
        setDupKind('phone');
        return;
      }
      const c = String(Math.floor(100000 + Math.random() * 900000));
      setCode(c); setEntered(''); setVerifyErr('');
      void sendVerificationCode(f.email.trim(), c);
      idemRef.current = `reg-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      setModal(true);
    } catch { setChecking(false); setErrors({ form: t('errGeneric') }); }
  };
  const verify = async () => {
    try {
      if (entered.trim() !== code) { setVerifyErr(t('codeMismatch')); return; }
      setBusy(true); setVerifyErr('');
      let dupAgain: 'email' | 'phone' | null = null;
      try { dupAgain = await findDuplicate(); } catch { dupAgain = null; }
      if (dupAgain) {
        setBusy(false); setModal(false);
        if (dupAgain === 'email') setErrors(prev => ({ ...prev, email: t('dupEmail') }));
        else setErrors(prev => ({ ...prev, phone: t('dupPhone') }));
        setDupKind(dupAgain);
        return;
      }
      const value = { fullName: f.fullName.trim(), email: f.email.trim().toLowerCase(), country: country?.name, countryCode: country?.code, phone: f.phone.trim(), dob: f.dob, gender: f.gender, agentId: f.agentId.trim(), password: f.password, createdVia: 'registration' };
      const rec = await api('records.create', { collection: 'customers', value, idempotency_key: idemRef.current });
      setBusy(false); setModal(false);
      setNotice(t('welcomeNotice'));
      onDone(rec?.value || value);
    } catch (err) {
      setBusy(false);
      setVerifyErr(t('errSave', { msg: err instanceof Error ? err.message : t('serviceUnavailable') }));
    }
  };
  const Err = ({ k }: { k: string }) => errors[k] ? <p className="err">{errors[k]}</p> : null;
  return (
    <div className="mx-auto max-w-[600px] py-8">
      <div className="card p-6 sm:p-8" style={{ background: 'linear-gradient(165deg, rgba(213,177,109,.10), rgba(24,18,18,.92))', backdropFilter: 'blur(8px)' }}>
        <h1 className="font-display text-3xl">{t('joinTitle')}</h1>
        <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>{t('joinSub')}</p>
        {errors.form && <p className="err">{errors.form}</p>}
        <form onSubmit={submit} noValidate className="mt-6 space-y-5">
          <div ref={el => { fieldRefs.current.fullName = el; }}><label className="lbl" htmlFor="fullName">{t('fullName')}</label><input id="fullName" className="field" value={f.fullName} onChange={set('fullName')} placeholder={t('yourFullName')} autoComplete="name" /><Err k="fullName" /></div>
          <div ref={el => { fieldRefs.current.email = el; }}><label className="lbl" htmlFor="email">{t('gmail')}</label><input id="email" className="field" type="email" value={f.email} onChange={set('email')} placeholder="you@gmail.com" autoComplete="email" /><Err k="email" /></div>
          <div ref={el => { fieldRefs.current.country = el; }}><label className="lbl">{t('country')}</label><CountrySelect value={country} onChange={onCountry} error={errors.country} t={t} /></div>
          <div ref={el => { fieldRefs.current.phone = el; }}><label className="lbl" htmlFor="phone">{t('phone')}</label><input id="phone" className="field" type="tel" value={f.phone} onChange={set('phone')} placeholder={country ? `+${country.code} …` : t('selectCountryFirst')} autoComplete="tel" /><Err k="phone" /></div>
          <div ref={el => { fieldRefs.current.dob = el; }}><label className="lbl" htmlFor="dob">{t('dob')}</label><input id="dob" className="field" type="date" max={maxDob()} value={f.dob} onChange={set('dob')} /><Err k="dob" /></div>
          <div ref={el => { fieldRefs.current.gender = el; }}><label className="lbl" htmlFor="gender">{t('gender')}</label>
            <select id="gender" className="field" value={f.gender} onChange={set('gender')}><option value="">{t('selectOption')}</option><option value="Woman">{t('woman')}</option><option value="Man">{t('man')}</option><option value="Non-binary">{t('nonBinary')}</option><option value="Prefer not to say">{t('preferNotSay')}</option></select><Err k="gender" /></div>
          <div ref={el => { fieldRefs.current.agentId = el; }}><label className="lbl" htmlFor="agentId">{t('agentId')}</label><input id="agentId" className="field" value={f.agentId} onChange={set('agentId')} placeholder="MDR-XXXXX00" autoComplete="off" />
            {agentState === 'ok' && <p className="ok-text flex items-center gap-1"><Check size={14} /> {t('agentVerified')}</p>}
            {agentState === 'bad' && <p className="err">{t('agentBad')}</p>}
            {agentState === 'typing' && <p className="mt-1 text-[13px]" style={{ color: 'var(--muted)' }}>{t('agentTyping')}</p>}
            <Err k="agentId" /></div>
          <div ref={el => { fieldRefs.current.password = el; }}><label className="lbl" htmlFor="password">{t('password')}</label><input id="password" className="field" type="password" value={f.password} onChange={set('password')} autoComplete="new-password" /><Err k="password" /></div>
          <div ref={el => { fieldRefs.current.confirm = el; }}><label className="lbl" htmlFor="confirm">{t('confirmPassword')}</label><input id="confirm" className="field" type="password" value={f.confirm} onChange={set('confirm')} autoComplete="new-password" /><Err k="confirm" /></div>
          <button type="submit" className="btn-gold w-full" disabled={checking}>{checking ? t('checking') : t('createAccount')}</button>
          <button type="button" className="btn-ghost w-full" onClick={() => go('home')}><ArrowLeft size={16} /> {t('goBack')}</button>
        </form>
      </div>
      {modal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4" style={{ background: 'rgba(0,0,0,.7)' }} role="dialog" aria-modal="true" aria-label={t('emailVerification')}>
          <div className="card w-full max-w-md rounded-b-none p-6 sm:rounded-b-[18px]">
            <h2 className="font-display text-2xl">{t('verifyTitle')}</h2>
            <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>{t('verifySub', { email: f.email })}</p>
            <p className="mt-3 flex items-center gap-2 text-sm" style={{ color: 'var(--ok)' }}><Check size={16} /> {t('codeSent')}</p>
            <input aria-label={t('verificationCode')} inputMode="numeric" className="field mt-4 text-center text-xl tracking-[.3em]" value={entered} onChange={e => setEntered(e.target.value.replace(/\D/g, '').slice(0, 6))} placeholder="••••••" />
            {verifyErr && <p className="err">{verifyErr}</p>}
            <button className="btn-gold mt-4 w-full" disabled={busy} onClick={verify}>{busy ? t('creatingAccount') : t('verifyCreate')}</button>
            <button className="btn-ghost mt-2 w-full" disabled={busy} onClick={() => setModal(false)}>{t('goBack')}</button>
          </div>
        </div>
      )}
      {dupKind && (
        <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4" style={{ background: 'rgba(0,0,0,.7)' }} role="dialog" aria-modal="true" aria-label={t('accountExistsLabel')}>
          <div className="card w-full max-w-md rounded-b-none p-6 sm:rounded-b-[18px]">
            <h2 className="font-display text-2xl">{t('alreadyTitle')}</h2>
            <p className="err mt-2" role="alert">{dupKind === 'email' ? t('dupEmail') : t('dupPhone')}</p>
            <button className="btn-gold mt-4 w-full" onClick={() => { setDupKind(''); go('login'); }}>{t('goToLogin')}</button>
            <button className="btn-ghost mt-2 w-full" onClick={() => setDupKind('')}>{t('goBack')}</button>
          </div>
        </div>
      )}
    </div>
  );
}

function Login({ go, onCustomer, onAgent, onAdminSecret, setNotice, t }: { go: (p: Page) => void; onCustomer: (c: any) => void; onAgent: (a: string) => void; onAdminSecret: () => void; setNotice: (s: string) => void; t: TFunc }) {
  const [tab, setTab] = useState<'member' | 'agent'>('member');
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [agentId, setAgentId] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    try {
      e.preventDefault(); setErr(''); setBusy(true);
      if (tab === 'agent') {
        const id = agentId.trim().toUpperCase();
        if (id === 'ADMIN-001') { setBusy(false); onAdminSecret(); return; }
        if (!AGENTS.includes(id)) { setErr(t('errAgentUnknown')); setBusy(false); return; }
        if (password.length < 4) { setErr(t('errAgentPassword')); setBusy(false); return; }
        setBusy(false); setNotice(t('welcomeAgent', { id })); onAgent(id); return;
      }
      const data = await api('records.list', { collection: 'customers', limit: 100 });
      const recs = data?.records || [];
      const found = recs.map((r: any) => r.value).find((v: any) => v?.email === email.trim().toLowerCase() && v?.password === password);
      setBusy(false);
      if (found) onCustomer(found); else setErr(t('errNoMatch'));
    } catch (ex) { setBusy(false); setErr(t('errLoginUnavailable', { msg: ex instanceof Error ? ex.message : t('serviceUnavailable') })); }
  };
  const tabLabel = (x: 'member' | 'agent') => x === 'member' ? t('memberLogin') : t('agentLogin');
  return (
    <div className="mx-auto max-w-[520px] py-10">
      <div className="card p-6 sm:p-8">
        <h1 className="font-display text-3xl">{t('welcomeBack')}</h1>
        <div className="mt-4 flex flex-wrap gap-2" role="tablist">
          {(['member', 'agent'] as const).map(x => (<button key={x} role="tab" aria-selected={tab === x} onClick={() => setTab(x)} className={tab === x ? 'btn-gold !min-h-[40px] text-sm' : 'btn-ghost !min-h-[40px] text-sm'}>{tabLabel(x)}</button>))}
        </div>
        <form onSubmit={submit} className="mt-5 space-y-4">
          {tab === 'agent' ? (<div><label className="lbl">{t('agentId')}</label><input className="field" value={agentId} onChange={e => setAgentId(e.target.value.toUpperCase())} placeholder="MDR-XXXXX00" /></div>)
            : (<div><label className="lbl">{t('gmail')}</label><input className="field" type="email" value={email} onChange={e => setEmail(e.target.value)} /></div>)}
          <div><label className="lbl">{t('password')}</label><input className="field" type="password" value={password} onChange={e => setPassword(e.target.value)} /></div>
          {err && <p className="err">{err}</p>}
          <button className="btn-gold w-full" disabled={busy}>{busy ? t('checkingLogin') : t('loginBtn')}</button>
          <button type="button" className="btn-ghost w-full" onClick={() => go('home')}><ArrowLeft size={16} /> {t('goBack')}</button>
        </form>
        <p className="mt-3 text-sm" style={{ color: 'var(--muted)' }}>{t('newHere')} <button className="gold underline" onClick={() => go('register')}>{t('joinMaison')}</button></p>
      </div>
    </div>
  );
}

type DashTab = 'Overview' | 'My Membership' | 'My Matches' | 'Introductions' | 'Video Calls' | 'Chat via Agent' | 'Card Orders' | 'Support Tickets' | 'Payments';
const TAB_KEY: Record<DashTab, string> = { 'Overview': 'tabOverview', 'My Membership': 'tabMembership', 'My Matches': 'tabMatches', 'Introductions': 'tabIntroductions', 'Video Calls': 'tabVideo', 'Chat via Agent': 'tabChat', 'Card Orders': 'tabCards', 'Support Tickets': 'tabTickets', 'Payments': 'tabPayments' };

function Dashboard({ go, customer, agentUser, onLogout, setNotice, t }: { go: (p: Page) => void; customer: any; agentUser: string | null; onLogout: () => void; setNotice: (s: string) => void; t: TFunc }) {
  const isAgent = !!agentUser;
  const tabs: DashTab[] = isAgent ? ['Overview', 'Payments', 'Support Tickets'] : ['Overview', 'My Membership', 'My Matches', 'Introductions', 'Video Calls', 'Chat via Agent', 'Card Orders', 'Support Tickets'];
  const [tab, setTab] = useState<DashTab>('Overview');
  const [invoices, setInvoices] = useState<any[]>([]);
  const [cards, setCards] = useState<any[]>([]);
  const [tickets, setTickets] = useState<any[]>([]);
  const [liaise, setLiaise] = useState<any>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [ticketForm, setTicketForm] = useState({ topic: 'Membership', message: '' });
  const [chatText, setChatText] = useState('');
  const [chatSent, setChatSent] = useState(false);

  const load = async () => {
    try {
      const [inv, cd, tk] = await Promise.all([
        api('records.list', { collection: 'invoices', limit: 100 }),
        api('records.list', { collection: 'cards', limit: 100 }),
        api('records.list', { collection: 'tickets', limit: 100 }),
      ]);
      const allInv = (inv?.records || []).map((r: any) => ({ _id: r.id, ...r.value }));
      const allCards = (cd?.records || []).map((r: any) => ({ _id: r.id, ...r.value }));
      const allTk = (tk?.records || []).map((r: any) => ({ _id: r.id, ...r.value }));
      if (isAgent) { setInvoices(allInv.filter((v: any) => v.agentId === agentUser)); setCards(allCards); setTickets(allTk); }
      else if (customer) { setInvoices(allInv.filter((v: any) => v.email === customer.email)); setCards(allCards.filter((v: any) => v.email === customer.email)); setTickets(allTk.filter((v: any) => v.email === customer.email)); }
    } catch { /* offline preview: keep empty state */ }
  };
  useEffect(() => { load(); }, [customer?.email, agentUser]);

  const activeMembership = invoices.find((v: any) => v.status === 'Verified');
  const pendingInvoice = invoices.find((v: any) => v.status === 'Pending Awaiting Agent Payment');

  const createInvoice = async (tier: any) => {
    if (!customer) { setMsg(t('loginFirst')); return; }
    setBusy(true); setMsg('');
    try {
      const invNo = randCode('MDR-INV');
      const value = { invoice: invNo, email: customer.email, fullName: customer.fullName, agentId: customer.agentId, tier: tier.name, amount: tier.price, status: 'Pending Awaiting Agent Payment', createdAt: new Date().toISOString() };
      await api('records.create', { collection: 'invoices', value, idempotency_key: `inv-${invNo}` });
      setLiaise(null); await load();
      setMsg(t('invoiceCreated', { inv: invNo }));
      setTab('My Membership');
    } catch (e) { setMsg(t('errCreateInvoice', { msg: e instanceof Error ? e.message : t('serviceUnavailable') })); }
    setBusy(false);
  };

  const orderCard = async () => {
    if (!customer) return;
    setBusy(true); setMsg('');
    try {
      const cardNo = randCode('MDR-CARD');
      const value = { card: cardNo, email: customer.email, fullName: customer.fullName, agentId: customer.agentId, amount: CARD_PRICE, status: 'Pending', createdAt: new Date().toISOString() };
      await api('records.create', { collection: 'cards', value, idempotency_key: `card-${cardNo}` });
      await load(); setMsg(t('cardOrdered', { card: cardNo }));
    } catch (e) { setMsg(t('errOrderCard', { msg: e instanceof Error ? e.message : t('serviceUnavailable') })); }
    setBusy(false);
  };

  const advanceCard = async (c: any) => {
    const idx = CARD_STATUSES.indexOf(c.status);
    if (idx < 0 || idx >= CARD_STATUSES.length - 1) return;
    setBusy(true);
    try {
      const { _id, ...rest } = c;
      await api('records.replace', { collection: 'cards', id: _id, value: { ...rest, status: CARD_STATUSES[idx + 1] } });
      await load();
    } catch (e) { setMsg(t('errUpdateCard', { msg: e instanceof Error ? e.message : t('serviceUnavailable') })); }
    setBusy(false);
  };

  const confirmPayment = async (inv: any) => {
    setBusy(true);
    try {
      const { _id, ...rest } = inv;
      await api('records.replace', { collection: 'invoices', id: _id, value: { ...rest, status: 'Verified' } });
      await load(); setNotice(t('paymentVerifiedNotice', { inv: inv.invoice }));
    } catch (e) { setMsg(t('errConfirm', { msg: e instanceof Error ? e.message : t('serviceUnavailable') })); }
    setBusy(false);
  };

  const createTicket = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setMsg('');
    try {
      const tNo = randCode('TICK');
      const value = { ticket: tNo, email: customer?.email || agentUser || '', topic: ticketForm.topic, message: ticketForm.message, status: 'Open', createdAt: new Date().toISOString() };
      await api('records.create', { collection: 'tickets', value, idempotency_key: `tick-${tNo}` });
      setTicketForm({ topic: 'Membership', message: '' }); await load(); setMsg(t('ticketCreated', { no: tNo }));
    } catch (err) { setMsg(t('errCreateTicket', { msg: err instanceof Error ? err.message : t('serviceUnavailable') })); }
    setBusy(false);
  };

  const badge = (s: string) => s === 'Verified'
    ? <span className="rounded-full px-3 py-1 text-xs font-semibold" style={{ background: 'rgba(127,201,127,.2)', color: 'var(--ok)' }}>{t('badgeVerified')}</span>
    : <span className="rounded-full px-3 py-1 text-xs font-semibold" style={{ background: 'rgba(232,207,154,.2)', color: '#e8cf9a' }}>{t('badgePending')}</span>;

  return (
    <div className="py-8">
      <div className="flex flex-wrap items-center gap-3">
        <div>
          <p className="text-xs uppercase tracking-[.25em]" style={{ color: 'var(--muted)' }}>{isAgent ? t('agentDash') : t('memberDash')}</p>
          <h1 className="font-display mt-1 text-3xl">{isAgent ? t('agentTitle', { id: agentUser }) : customer ? t('bonjour', { name: customer.fullName || 'Member' }) : t('bonjourPlain')}</h1>
        </div>
        <div className="ml-auto flex flex-wrap gap-2">
          <button className="btn-ghost !min-h-[40px] text-sm" onClick={load}>{t('refresh')}</button>
          <button className="btn-ghost !min-h-[40px] text-sm" onClick={onLogout}>{t('logout')}</button>
          <button className="btn-ghost !min-h-[40px] text-sm" onClick={() => go('home')}><ArrowLeft size={16} /> {t('goBack')}</button>
        </div>
      </div>
      <div className="mt-5 flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label={t('dashboardSections')}>
        {tabs.map(x => (<button key={x} role="tab" aria-selected={tab === x} onClick={() => setTab(x)} className={(tab === x ? 'btn-gold ' : 'btn-ghost ') + '!min-h-[40px] whitespace-nowrap text-sm'}>{t(TAB_KEY[x])}</button>))}
      </div>
      {msg && <div className="card mt-4 p-3 text-sm flex justify-between gap-3"><span>{msg}</span><button aria-label={t('dismiss')} onClick={() => setMsg('')}><X size={16} /></button></div>}

      {tab === 'Overview' && (
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <div className="card p-6">
            <User style={{ color: 'var(--gold)' }} />
            <h2 className="font-display mt-2 text-xl">{isAgent ? t('yourMembers') : t('yourProfile')}</h2>
            {isAgent ? <p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('agentMembersText')}</p>
              : customer ? <div className="mt-2 space-y-1 text-sm"><p>{customer.fullName}</p><p style={{ color: 'var(--muted)' }}>{customer.email}</p><p style={{ color: 'var(--muted)' }}>{customer.country} (+{customer.countryCode}) · {customer.phone}</p><p className="flex items-center gap-2"><BadgeCheck style={{ color: 'var(--ok)' }} size={16} /> {t('agentLine', { id: customer.agentId })}</p></div>
              : <p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('signInSee')}</p>}
          </div>
          <div className="card p-6">
            <Crown style={{ color: 'var(--gold)' }} />
            <h2 className="font-display mt-2 text-xl">{t('membershipStatus')}</h2>
            {activeMembership ? <p className="mt-2 text-sm">{activeMembership.tier} — <span style={{ color: 'var(--ok)' }}>{t('membershipActiveWord')}</span> ({activeMembership.invoice})</p>
              : pendingInvoice ? <p className="mt-2 flex flex-wrap items-center gap-2 text-sm">{pendingInvoice.tier} {badge(pendingInvoice.status)}</p>
              : <p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('noMembership')}</p>}
            {!isAgent && <button className="btn-gold mt-4 text-sm" onClick={() => setTab('My Membership')}>{t('viewMembership')}</button>}
          </div>
        </div>
      )}

      {tab === 'My Membership' && !isAgent && (
        <div className="mt-5">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {TIERS.map(tier => (
              <div key={tier.name} className="card p-5">
                <Crown style={{ color: 'var(--gold)' }} size={20} />
                <h3 className="mt-2 font-display text-xl">{tier.name}</h3>
                <p className="gold mt-1 text-lg">{tier.label}</p>
                <p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t(tier.descKey)}</p>
                {activeMembership?.tier === tier.name ? <p className="ok-text mt-3 flex items-center gap-1"><Check size={14} /> {t('membershipActiveShort')}</p>
                  : <button className="btn-gold mt-4 w-full text-sm" onClick={() => setLiaise(tier)}>{t('selectTier', { name: tier.name })}</button>}
              </div>
            ))}
          </div>
          <div className="card mt-4 flex flex-wrap items-center gap-4 p-6" style={{ borderColor: 'var(--gold)' }}>
            <CreditCard style={{ color: 'var(--gold)' }} />
            <div className="min-w-[220px] flex-1"><h3 className="font-display text-xl">{t('priveTitle')}</h3><p className="text-sm" style={{ color: 'var(--muted)' }}>{t('priveDescDash')}</p></div>
            <button className="btn-ghost" onClick={() => setTab('Card Orders')}>{t('goCardOrders')}</button>
          </div>
          <h3 className="font-display mt-8 text-xl">{t('yourInvoices')}</h3>
          {invoices.length === 0 ? <p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('noInvoices')}</p> : (
            <div className="mt-3 space-y-3">{invoices.map((v: any) => (
              <div key={v._id || v.invoice} className="card flex flex-wrap items-center gap-3 p-4 text-sm">
                <span className="font-semibold">{v.invoice}</span><span>{v.tier}</span><span className="gold">${Number(v.amount).toFixed(2)}</span>{badge(v.status)}
                {v.status === 'Verified' && <span style={{ color: 'var(--ok)' }}>{t('membershipActiveWord')}</span>}
              </div>))}
            </div>)}
        </div>
      )}

      {tab === 'Payments' && isAgent && (
        <div className="mt-5">
          <h2 className="font-display text-xl">{t('paymentsTitle')}</h2>
          <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>{t('paymentsSub')}</p>
          {invoices.length === 0 ? <p className="mt-3 text-sm" style={{ color: 'var(--muted)' }}>{t('noInvoicesAgent')}</p> : (
            <div className="mt-3 space-y-3">{invoices.map((v: any) => (
              <div key={v._id || v.invoice} className="card flex flex-wrap items-center gap-3 p-4 text-sm">
                <span className="font-semibold">{v.invoice}</span><span>{v.fullName} ({v.email})</span><span>{v.tier}</span><span className="gold">${Number(v.amount).toFixed(2)}</span>{badge(v.status)}
                {v.status !== 'Verified' && <button className="btn-gold !min-h-[40px] text-sm" disabled={busy} onClick={() => confirmPayment(v)}>{t('confirmPayment')}</button>}
                {v.status === 'Verified' && <span style={{ color: 'var(--ok)' }}>{t('membershipActiveWord')}</span>}
              </div>))}
            </div>)}
        </div>
      )}

      {tab === 'My Matches' && (<div className="card mt-5 p-6"><Heart style={{ color: 'var(--gold)' }} /><h2 className="font-display mt-2 text-xl">{t('matchesTitle')}</h2><p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('matchesText')}</p></div>)}
      {tab === 'Introductions' && (<div className="card mt-5 p-6"><CalendarHeart style={{ color: 'var(--gold)' }} /><h2 className="font-display mt-2 text-xl">{t('introTitle')}</h2><p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('introText')}</p></div>)}
      {tab === 'Video Calls' && (<div className="card mt-5 p-6"><Video style={{ color: 'var(--gold)' }} /><h2 className="font-display mt-2 text-xl">{t('videoTitle')}</h2><p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('videoText')}</p></div>)}

      {tab === 'Chat via Agent' && (
        <div className="card mt-5 p-6">
          <MessageCircle style={{ color: 'var(--gold)' }} />
          <h2 className="font-display mt-2 text-xl">{t('chatTitle')}</h2>
          <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>{t('chatSub', { agent: customer ? ` (${customer.agentId})` : '' })}</p>
          {chatSent ? <p className="ok-text mt-4">{t('chatSent')}</p> : (
            <form className="mt-4 space-y-3" onSubmit={e => { e.preventDefault(); setChatSent(true); }}>
              <textarea aria-label={t('msgToAgent')} className="field" rows={4} required value={chatText} onChange={e => setChatText(e.target.value)} placeholder={t('chatPh')} />
              <button className="btn-gold">{t('sendViaAgent')}</button>
            </form>)}
        </div>
      )}

      {tab === 'Card Orders' && !isAgent && (
        <div className="mt-5">
          <div className="card flex flex-wrap items-center gap-4 p-6">
            <CreditCard style={{ color: 'var(--gold)' }} />
            <div className="min-w-[220px] flex-1"><h2 className="font-display text-xl">{t('priveTitle')}</h2><p className="text-sm" style={{ color: 'var(--muted)' }}>{t('priveDescCard')}</p></div>
            <button className="btn-gold" disabled={busy} onClick={orderCard}>{busy ? t('ordering') : t('orderCardBtn')}</button>
          </div>
          {cards.length === 0 ? <p className="mt-4 text-sm" style={{ color: 'var(--muted)' }}>{t('noCards')}</p> : (
            <div className="mt-4 space-y-3">{cards.map((c: any) => (
              <div key={c._id || c.card} className="card p-4">
                <div className="flex flex-wrap items-center gap-3 text-sm"><span className="font-semibold">{c.card}</span><span className="gold">$250</span><span className="rounded-full px-3 py-1 text-xs font-semibold" style={{ background: 'rgba(213,177,109,.18)', color: 'var(--gold)' }}>{t(CS_KEY[c.status] || 'csPending')}</span>
                  {c.status !== 'Delivered' && <button className="btn-ghost !min-h-[40px] text-sm" disabled={busy} onClick={() => advanceCard(c)}>{t('updateStatus')}</button>}</div>
                <div className="mt-3 flex flex-wrap gap-1">{CARD_STATUSES.map((s, i) => (<span key={s} className="rounded-full px-2 py-1 text-[11px]" style={{ background: CARD_STATUSES.indexOf(c.status) >= i ? 'var(--gold)' : 'rgba(255,255,255,.08)', color: CARD_STATUSES.indexOf(c.status) >= i ? '#171106' : 'var(--muted)' }}>{t(CS_KEY[s])}</span>))}</div>
              </div>))}
            </div>)}
        </div>
      )}

      {tab === 'Support Tickets' && (
        <div className="mt-5 grid gap-4 lg:grid-cols-2">
          <div className="card p-6">
            <Ticket style={{ color: 'var(--gold)' }} />
            <h2 className="font-display mt-2 text-xl">{t('newTicket')}</h2>
            <form className="mt-4 space-y-3" onSubmit={createTicket}>
              <div><label className="lbl">{t('topic')}</label><select className="field" value={ticketForm.topic} onChange={e => setTicketForm({ ...ticketForm, topic: e.target.value })}><option value="Membership">{t('topicMembership')}</option><option value="Payment via agent">{t('topicPayment')}</option><option value="My introduction">{t('topicIntro')}</option><option value="Maison Privé Card">{t('topicCard')}</option><option value="Something else">{t('topicOther')}</option></select></div>
              <div><label className="lbl">{t('message')}</label><textarea className="field" rows={4} required value={ticketForm.message} onChange={e => setTicketForm({ ...ticketForm, message: e.target.value })} /></div>
              <button className="btn-gold w-full" disabled={busy}>{busy ? t('creating') : t('createTicket')}</button>
            </form>
          </div>
          <div className="card p-6">
            <h2 className="font-display text-xl">{t('yourTickets')}</h2>
            {tickets.length === 0 ? <p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('noTickets')}</p> : (
              <div className="mt-3 space-y-3">{tickets.map((tk: any) => (<div key={tk._id || tk.ticket} className="rounded-xl border p-3 text-sm" style={{ borderColor: 'var(--line)' }}><p className="font-semibold">{tk.ticket} · {tk.topic}</p><p className="mt-1" style={{ color: 'var(--muted)' }}>{tk.message}</p><p className="mt-1 text-xs" style={{ color: 'var(--ok)' }}>{tk.status}</p></div>))}
              </div>)}
          </div>
        </div>
      )}

      {liaise && (
        <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4" style={{ background: 'rgba(0,0,0,.7)' }} role="dialog" aria-modal="true" aria-label={t('liaiseTitle')}>
          <div className="card w-full max-w-md rounded-b-none p-6 sm:rounded-b-[18px]">
            <h2 className="font-display text-2xl">{t('liaiseTitle')}</h2>
            <p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('liaiseSelected', { name: liaise.name, label: liaise.label })}</p>
            <p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>{t('liaiseText')}</p>
            {customer && <p className="mt-2 text-sm">{t('yourAgent')} <span className="gold">{customer.agentId}</span></p>}
            <button className="btn-gold mt-4 w-full" disabled={busy} onClick={() => createInvoice(liaise)}>{busy ? t('creatingInvoice') : t('createInvoice')}</button>
            <button className="btn-ghost mt-2 w-full" disabled={busy} onClick={() => setLiaise(null)}>{t('goBack')}</button>
          </div>
        </div>
      )}
    </div>
  );
}

function Support({ go, t }: { go: (p: Page) => void; t: TFunc }) {
  const [sent, setSent] = useState(false);
  return (<div className="mx-auto max-w-xl py-10"><div className="card p-6 sm:p-8">
    <h1 className="font-display text-3xl">{t('supportTitle')}</h1>
    <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>{t('supportSub')}</p>
    {sent ? <p className="ok-text mt-4">{t('supportSent')}</p> : (
      <form className="mt-5 space-y-4" onSubmit={e => { e.preventDefault(); setSent(true); }}>
        <div><label className="lbl">{t('topic')}</label><select className="field"><option value="Membership">{t('topicMembership')}</option><option value="My introduction">{t('topicIntro')}</option><option value="Billing">{t('topicBilling')}</option><option value="Something else">{t('topicOther')}</option></select></div>
        <div><label className="lbl">{t('message')}</label><textarea className="field" rows={4} required /></div>
        <button className="btn-gold w-full">{t('sendConcierge')}</button>
      </form>)}
    <button className="btn-ghost mt-4 w-full" onClick={() => go('home')}><ArrowLeft size={16} /> {t('goBack')}</button>
  </div></div>);
}

function Guide({ go, t }: { go: (p: Page) => void; t: TFunc }) {
  const [copied, setCopied] = useState('');
  const vars = [['NEXT_PUBLIC_APP_NAME', 'Maison de Romance'], ['NEXT_PUBLIC_PRODUCTION_MODE', 'true'], ['MAISON_ADMIN_EMAIL', 'admin@maisondromance.com'], ['MAISON_SUPPORT_EMAIL', 'concierge@maisondromance.com']];
  return (<div className="mx-auto max-w-2xl py-10"><div className="card p-6 sm:p-8">
    <h1 className="font-display text-3xl">{t('guideTitle')}</h1>
    <ol className="mt-4 list-decimal space-y-2 pl-5 text-sm" style={{ color: 'var(--muted)' }}>
      <li>{t('g1')}</li>
      <li>{t('g2')}</li>
      <li>{t('g3')}</li>
      <li>{t('g4')}</li>
    </ol>
    <div className="mt-6 space-y-3">
      {vars.map(([k, v]) => (<div key={k} className="flex flex-wrap items-center gap-2 rounded-xl border p-3" style={{ borderColor: 'var(--line)' }}>
        <code className="text-sm flex-1 break-all">{k}={v}</code>
        <button className="btn-ghost !min-h-[40px] text-sm" onClick={() => copyText(`${k}=${v}`, () => setCopied(k))}>{copied === k ? <><Check size={14} /> {t('copied')}</> : <><Copy size={14} /> {t('copy')}</>}</button>
      </div>))}
    </div>
    <button className="btn-ghost mt-6 w-full" onClick={() => go('home')}><ArrowLeft size={16} /> {t('goBack')}</button>
  </div></div>);
}

function Checklist({ go, production, customer, t }: { go: (p: Page) => void; production: boolean; customer: any; t: TFunc }) {
  const items: [string, boolean][] = [
    [t('c1'), production],
    [t('c2'), production],
    [t('c3'), true],
    [t('c4'), true],
    [t('c5'), true],
    [t('c6'), true],
    [t('c7'), true],
    [t('c8'), true],
    [t('c9'), !!customer],
    [t('c10'), true],
  ];
  return (<div className="mx-auto max-w-2xl py-10"><div className="card p-6 sm:p-8">
    <h1 className="font-display text-3xl">{t('checklistTitle')}</h1>
    <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>{t('checklistSub')}</p>
    <ul className="mt-5 space-y-3">
      {items.map(([text, ok]) => (<li key={text} className="flex items-center gap-3 rounded-xl border p-3" style={{ borderColor: 'var(--line)' }}>
        {ok ? <Check style={{ color: 'var(--ok)' }} /> : <X style={{ color: 'var(--danger)' }} />}<span className="text-sm">{text}</span>
        <span className="ml-auto text-xs" style={{ color: ok ? 'var(--ok)' : 'var(--danger)' }}>{ok ? t('ready') : t('pending')}</span></li>))}
    </ul>
    <div className="mt-6 flex flex-wrap gap-3">
      <button className="btn-gold" onClick={() => go('register')}>{t('testRegistration')}</button>
      <button className="btn-ghost" onClick={() => go('guide')}>{t('guideBtn')}</button>
      <button className="btn-ghost" onClick={() => go('home')}><ArrowLeft size={16} /> {t('goBack')}</button>
    </div>
  </div></div>);
}
